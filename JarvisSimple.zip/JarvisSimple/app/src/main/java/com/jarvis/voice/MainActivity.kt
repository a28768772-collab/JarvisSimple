package com.jarvis.voice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var reply: TextView
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var ttsReady = false

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok -> if (ok) listenNow() else say("माइक्रोफोन की अनुमति चाहिए।") }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        heard = findViewById(R.id.heard)
        reply = findViewById(R.id.reply)
        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.listen).setOnClickListener {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                micPermission.launch(Manifest.permission.RECORD_AUDIO)
            else listenNow()
        }
        findViewById<Button>(R.id.stop).setOnClickListener { stopJarvis() }
    }

    private fun listenNow() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech recognition उपलब्ध नहीं है।"); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { status.text = "स्थिति: सुन रहा हूँ..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "स्थिति: समझ रहा हूँ..." }
            override fun onError(e: Int) { status.text = "स्थिति: तैयार"; reply.text = "JARVIS: आवाज़ समझ नहीं आई।" }
            override fun onResults(r: Bundle?) {
                val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                heard.text = "आपने कहा: $text"
                command(text)
            }
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        recognizer!!.startListening(i)
    }

    private fun command(raw: String) {
        val c = raw.lowercase(Locale.getDefault())
        when {
            c.contains("youtube") || c.contains("यूट्यूब") -> {
                open("https://www.youtube.com"); say("YouTube खोल रहा हूँ।")
            }
            c.contains("google") || c.contains("गूगल") -> {
                open("https://www.google.com"); say("Google खोल रहा हूँ।")
            }
            c.contains("समय") || c.contains("time") -> {
                val t = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                say("अभी समय $t है।")
            }
            c.contains("stop") || c.contains("स्टॉप") -> stopJarvis()
            c.contains("hello") || c.contains("हैलो") || c.contains("नमस्ते") || c.contains("हाय") ->
                say("नमस्ते सर। JARVIS तैयार है।")
            else -> say("यह command अभी basic mode में उपलब्ध नहीं है।")
        }
    }

    private fun open(url: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun say(text: String) {
        status.text = "स्थिति: तैयार"
        reply.text = "JARVIS: $text"
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "JARVIS")
    }

    private fun stopJarvis() {
        recognizer?.cancel()
        status.text = "स्थिति: STOP"
        reply.text = "JARVIS: रोक दिया गया है।"
        if (ttsReady) tts.speak("Jarvis रोक दिया गया है।", TextToSpeech.QUEUE_FLUSH, null, "JARVIS")
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts.language = Locale("hi", "IN")
            tts.setSpeechRate(0.85f)
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
