JARVIS Simple Android Project

Android Studio:
1. Open this folder as a project.
2. Wait for Gradle Sync.
3. Run on an Android phone/emulator.
4. Allow microphone permission.
5. Tap "JARVIS सुनो" and speak Hindi.

Basic commands:
- YouTube खोलो
- Google खोलो
- समय बताओ
- नमस्ते
- STOP

Note: This simple mode is not a continuous wake-word/background assistant.
